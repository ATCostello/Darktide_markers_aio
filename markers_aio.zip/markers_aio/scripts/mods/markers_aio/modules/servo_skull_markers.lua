local mod = get_mod("markers_aio")
local PlayerUnitStatus = require("scripts/utilities/attack/player_unit_status")
local fs = mod.frame_settings

local function _is_decoder_active(minigame_extension)
	if not minigame_extension then
		return false
	end
	return minigame_extension:is_active()
end

mod.update_servo_skull_markers = function(self, marker)
	if marker and self then
		local unit = marker.unit
		if not unit or type(unit) ~= "userdata" or not Unit.alive(unit) then
			return
		end

		local decoder_ext = mod.get_marker_extension(marker, "decoder_device_system")
		local is_decoding_terminal = decoder_ext and decoder_ext:unit_is_enabled() and not decoder_ext:is_finished()

		if not is_decoding_terminal then
			return
		end

		local unit_data_extension = ScriptUnit.has_extension(unit, "unit_data_system")

		local widget = marker.widget
		if not widget or not widget.style or not widget.style.background then
			return
		end

		marker.draw = false
		widget.alpha_multiplier = 0
		widget.visible = true

		marker.markers_aio_type = "servo_skull"

		local pt = fs.per_type.servo_skull

		mod.set_colour(widget.style.background.color, mod.lookup_colour(fs.marker_background_colour))
		marker.template.check_line_of_sight = pt.require_line_of_sight
		marker.template.max_distance = pt.max_distance
		marker.template.screen_clamp = pt.keep_on_screen
		marker.block_screen_clamp = false

		local character_state_component = unit_data_extension and unit_data_extension:read_component("character_state")
			or nil
		if character_state_component and PlayerUnitStatus.is_ledge_hanging(character_state_component) then
			--
		elseif not is_decoding_terminal and fs and fs.servo_skull_equipped then
			widget.content.icon = fs.servo_skull_icon
		elseif is_decoding_terminal then
			widget.content.icon = fs.decoding_icon
		end

		marker.template.icon_min_size[1] = 36
		marker.template.icon_min_size[2] = 36
		marker.template.icon_max_size[1] = 48
		marker.template.icon_max_size[2] = 48

		local minigame_extension = ScriptUnit.has_extension(unit, "minigame_system")
		local colour_type = "servo_skull_default"
		local border_key = "servo_skull_border_colour"
		marker.servo_skull_pulse = false

		if is_decoding_terminal then
			if decoder_ext then
				if decoder_ext:wait_for_restart() then
					colour_type = "servo_skull_stalled"
					border_key = "servo_skull_stalled_border_colour"
					marker.servo_skull_pulse = fs.servo_skull_pulse_when_stalled
					if fs and fs.servo_skull_equipped then
						widget.content.icon = fs.servo_skull_icon
					end
				elseif
					decoder_ext:started_decode()
					and not decoder_ext:is_finished()
					and decoder_ext:is_minigame_active()
				then
					colour_type = "servo_skull_active"
					border_key = "servo_skull_active_border_colour"
					marker.servo_skull_pulse = false
					if fs and fs.servo_skull_equipped then
						widget.content.icon = fs.servo_skull_icon
					end
				end
			else
				local interactee_extension = ScriptUnit.has_extension(unit, "interactee_system")
				local player = mod.get_local_player()
				local player_unit = player and player.player_unit

				if minigame_extension and _is_decoder_active(minigame_extension) then
					colour_type = "servo_skull_active"
					border_key = "servo_skull_active_border_colour"
					marker.servo_skull_pulse = false
				elseif player_unit and interactee_extension and interactee_extension:show_marker(player_unit) then
					colour_type = "servo_skull_stalled"
					border_key = "servo_skull_stalled_border_colour"
					marker.servo_skull_pulse = fs.servo_skull_pulse_when_stalled
				end
			end
		end

		if widget.style.ring then
			mod.set_colour(widget.style.ring.color, mod.lookup_colour(fs[border_key]))
		end

		mod.set_colour_argb(
			widget.style.icon.color,
			255,
			fs[colour_type .. "_colour_R"],
			fs[colour_type .. "_colour_G"],
			fs[colour_type .. "_colour_B"]
		)

		marker.draw = true
		if not widget.removed then
			widget.alpha_multiplier = 1
		end
	end
end
