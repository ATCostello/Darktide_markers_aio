local mod = get_mod("markers_aio")

local HudElementWorldMarkers = require("scripts/ui/hud/elements/world_markers/hud_element_world_markers")
local Pickups = require("scripts/settings/pickup/pickups")
local HUDElementInteractionSettings = require("scripts/ui/hud/elements/interaction/hud_element_interaction_settings")
local WorldMarkerTemplateInteraction =
	require("scripts/ui/hud/elements/world_markers/templates/world_marker_template_interaction")
local UIWidget = require("scripts/managers/ui/ui_widget")

local fs = mod.frame_settings

local get_max_distance = function()
	local max_distance = fs.stimm_max_distance

	if max_distance == nil then
		max_distance = fs.stimm_max_distance
	end

	return max_distance
end

local set_stimm_colours = function(marker, stimm_name, border_setting, r_setting, g_setting, b_setting)
	local widget_icon_or_background = marker.widget.style.icon.color

	-- if toggle background colour, then set the background as is
	if fs.toggle_background_colour then
		if mod.RecolorStimms then
			local argb = mod.RecolorStimms.get_stimm_argb_255(stimm_name)
			mod.set_colour_argb(marker.widget.style.background.color, argb[1], argb[2], argb[3], argb[4])
		else
			mod.set_colour_argb(marker.widget.style.background.color, 255, fs[r_setting], fs[g_setting], fs[b_setting])
		end
	end

	-- if toggle background colour, then set icon to be the inverse...
	if fs.toggle_background_colour then
		mod.set_colour(marker.widget.style.icon.color, mod.lookup_colour(fs.marker_background_colour))
	else
		if mod.RecolorStimms then
			local argb = mod.RecolorStimms.get_stimm_argb_255(stimm_name)
			mod.set_colour_argb(marker.widget.style.icon.color, argb[1], argb[2], argb[3], argb[4])
		else
			mod.set_colour_argb(marker.widget.style.icon.color, 255, fs[r_setting], fs[g_setting], fs[b_setting])
		end
	end

	mod.set_colour(marker.widget.style.ring.color, mod.lookup_colour(fs[border_setting]))
end

mod.update_stimm_markers = function(self, marker)
	local max_distance = get_max_distance()

	if marker and self then
		local unit = marker.unit

		local pickup_type = mod.get_marker_pickup_type(marker)

		if
			pickup_type and pickup_type == "syringe_power_boost_pocketable"
			or pickup_type and pickup_type == "syringe_speed_boost_pocketable"
			or pickup_type and pickup_type == "syringe_ability_boost_pocketable"
			or pickup_type and pickup_type == "syringe_corruption_pocketable"
			or marker.data and marker.data.type == "syringe_power_boost_pocketable"
			or marker.data and marker.data.type == "syringe_speed_boost_pocketable"
			or marker.data and marker.data.type == "syringe_ability_boost_pocketable"
			or marker.data and marker.data.type == "syringe_corruption_pocketable"
			or pickup_type and pickup_type == "syringe_broker_pocketable"
			or marker.data and marker.data.type == "syringe_broker_pocketable"
		then
			marker.markers_aio_type = "stimm"
			-- force hide marker to start, to prevent "pop in" where the marker will briefly appear at max opacity
			marker.widget.alpha_multiplier = 0
			marker.draw = false

			marker.template.screen_clamp = fs.stimm_keep_on_screen
			marker.block_screen_clamp = false

			-- marker.widget.content.is_clamped = false

			local max_spawn_distance_sq = max_distance * max_distance
			HUDElementInteractionSettings.max_spawn_distance_sq = max_spawn_distance_sq

			if self.fade_settings then
				self.fade_settings.distance_max = max_distance
				self.fade_settings.distance_min = max_distance - self.evolve_distance * 2
			end

			marker.template.max_distance = max_distance
			marker.template.fade_settings.distance_max = max_distance
			marker.template.fade_settings.distance_min = max_distance - marker.template.evolve_distance * 2

			self.max_distance = max_distance
			marker.max_distance = max_distance

			if self.fade_settings then
				self.fade_settings.distance_max = max_distance
				self.fade_settings.distance_min = max_distance - self.evolve_distance * 2
			end

			mod.set_colour(marker.widget.style.background.color, mod.lookup_colour(fs.marker_background_colour))

			if
				pickup_type == "syringe_power_boost_pocketable"
				or marker.data and marker.data.type == "syringe_power_boost_pocketable"
			then
				marker.aio_check_line_of_sight = fs.power_stimm_require_line_of_sight
				set_stimm_colours(
					marker,
					pickup_type,
					"power_stimm_border_colour",
					"power_stimm_icon_colour_R",
					"power_stimm_icon_colour_G",
					"power_stimm_icon_colour_B"
				)
			elseif
				pickup_type == "syringe_speed_boost_pocketable"
				or marker.data and marker.data.type == "syringe_speed_boost_pocketable"
			then
				marker.aio_check_line_of_sight = fs.speed_stimm_require_line_of_sight
				set_stimm_colours(
					marker,
					pickup_type,
					"speed_stimm_border_colour",
					"speed_stimm_icon_colour_R",
					"speed_stimm_icon_colour_G",
					"speed_stimm_icon_colour_B"
				)
			elseif
				pickup_type == "syringe_ability_boost_pocketable"
				or marker.data and marker.data.type == "syringe_ability_boost_pocketable"
			then
				marker.aio_check_line_of_sight = fs.boost_stimm_require_line_of_sight
				set_stimm_colours(
					marker,
					pickup_type,
					"boost_stimm_border_colour",
					"boost_stimm_icon_colour_R",
					"boost_stimm_icon_colour_G",
					"boost_stimm_icon_colour_B"
				)
			elseif
				pickup_type == "syringe_corruption_pocketable"
				or marker.data and marker.data.type == "syringe_corruption_pocketable"
			then
				marker.aio_check_line_of_sight = fs.corruption_stimm_require_line_of_sight
				set_stimm_colours(
					marker,
					pickup_type,
					"corruption_stimm_border_colour",
					"corruption_stimm_icon_colour_R",
					"corruption_stimm_icon_colour_G",
					"corruption_stimm_icon_colour_B"
				)
			elseif
				pickup_type == "syringe_broker_pocketable"
				or marker.data and marker.data.type == "syringe_broker_pocketable"
			then
				if fs.broker_stimm_enable == true then
					marker.aio_check_line_of_sight = fs.broker_stimm_require_line_of_sight
					set_stimm_colours(
						marker,
						pickup_type,
						"broker_stimm_border_colour",
						"broker_stimm_icon_colour_R",
						"broker_stimm_icon_colour_G",
						"broker_stimm_icon_colour_B"
					)
				end
			end
		end
	end
end

-- update player weapon stimm icon colour
mod:hook_safe(CLASS.HudElementPlayerWeapon, "update", function(self, dt, t, ui_renderer)
	local inventory_component = self._inventory_component

	local weapon_name = self._weapon_name
	local widget = self._widgets_by_name.icon

	if weapon_name == "content/items/pocketable/syringe_power_boost_pocketable" then
		if mod.RecolorStimms then
			local argb = mod.RecolorStimms.get_stimm_argb_255("syringe_power_boost_pocketable")
			mod.set_colour_argb(widget.style.icon.color, argb[1], argb[2], argb[3], argb[4])
		else
			mod.set_colour_argb(
				widget.style.icon.color,
				255,
				fs.power_stimm_icon_colour_R,
				fs.power_stimm_icon_colour_G,
				fs.power_stimm_icon_colour_B
			)
		end
	elseif weapon_name == "content/items/pocketable/syringe_speed_boost_pocketable" then
		if mod.RecolorStimms then
			local argb = mod.RecolorStimms.get_stimm_argb_255("syringe_speed_boost_pocketable")
			mod.set_colour_argb(widget.style.icon.color, argb[1], argb[2], argb[3], argb[4])
		else
			mod.set_colour_argb(
				widget.style.icon.color,
				255,
				fs.speed_stimm_icon_colour_R,
				fs.speed_stimm_icon_colour_G,
				fs.speed_stimm_icon_colour_B
			)
		end
	elseif weapon_name == "content/items/pocketable/syringe_ability_boost_pocketable" then
		if mod.RecolorStimms then
			local argb = mod.RecolorStimms.get_stimm_argb_255("syringe_ability_boost_pocketable")
			mod.set_colour_argb(widget.style.icon.color, argb[1], argb[2], argb[3], argb[4])
		else
			mod.set_colour_argb(
				widget.style.icon.color,
				255,
				fs.boost_stimm_icon_colour_R,
				fs.boost_stimm_icon_colour_G,
				fs.boost_stimm_icon_colour_B
			)
		end
	elseif weapon_name == "content/items/pocketable/syringe_corruption_pocketable" then
		if mod.RecolorStimms then
			local argb = mod.RecolorStimms.get_stimm_argb_255("syringe_corruption_pocketable")
			mod.set_colour_argb(widget.style.icon.color, argb[1], argb[2], argb[3], argb[4])
		else
			mod.set_colour_argb(
				widget.style.icon.color,
				255,
				fs.corruption_stimm_icon_colour_R,
				fs.corruption_stimm_icon_colour_G,
				fs.corruption_stimm_icon_colour_B
			)
		end
	elseif weapon_name == "content/items/pocketable/syringe_broker_pocketable" then
		if fs.broker_stimm_enable == true then
			if mod.RecolorStimms then
				local argb = mod.RecolorStimms.get_stimm_argb_255("syringe_broker_pocketable")
				mod.set_colour_argb(widget.style.icon.color, argb[1], argb[2], argb[3], argb[4])
			else
				mod.set_colour_argb(
					widget.style.icon.color,
					255,
					fs.broker_stimm_icon_colour_R,
					fs.broker_stimm_icon_colour_G,
					fs.broker_stimm_icon_colour_B
				)
			end
		end
	end
end)

-- update team panel stimm icon colour
local PlayerUnitVisualLoadout = require("scripts/extension_systems/visual_loadout/utilities/player_unit_visual_loadout")

mod:hook_safe(
	CLASS.HudElementTeamPanelHandler,
	"update",
	function(self, dt, t, ui_renderer, render_settings, input_service)
		local weapon_name = ""
		local players = Managers.player:players()
		local player_panels_array = self._player_panels_array

		for _, player in pairs(players) do
			local player_unit = player.player_unit

			if ALIVE[player_unit] then
				-- grab slot_pocketable_small item
				local visual_loadout_extension = ScriptUnit.extension(player_unit, "visual_loadout_system")
				local item = visual_loadout_extension:item_from_slot("slot_pocketable_small")

				if item then
					weapon_name = item.name

					-- grab stim widget for player
					for _, panel_array in pairs(player_panels_array) do
						if panel_array.player._account_id == player._account_id then
							local stimm_widget = panel_array.panel._widgets_by_name.pocketable_small

							if stimm_widget and weapon_name ~= "" then
								if weapon_name == "content/items/pocketable/syringe_power_boost_pocketable" then
									if mod.RecolorStimms then
										local argb =
											mod.RecolorStimms.get_stimm_argb_255("syringe_power_boost_pocketable")
										mod.set_colour_argb(
											stimm_widget.style.texture.color,
											argb[1],
											argb[2],
											argb[3],
											argb[4]
										)
									else
										mod.set_colour_argb(
											stimm_widget.style.texture.color,
											255,
											fs.power_stimm_icon_colour_R,
											fs.power_stimm_icon_colour_G,
											fs.power_stimm_icon_colour_B
										)
									end
								elseif weapon_name == "content/items/pocketable/syringe_speed_boost_pocketable" then
									if mod.RecolorStimms then
										local argb =
											mod.RecolorStimms.get_stimm_argb_255("syringe_speed_boost_pocketable")
										mod.set_colour_argb(
											stimm_widget.style.texture.color,
											argb[1],
											argb[2],
											argb[3],
											argb[4]
										)
									else
										mod.set_colour_argb(
											stimm_widget.style.texture.color,
											255,
											fs.speed_stimm_icon_colour_R,
											fs.speed_stimm_icon_colour_G,
											fs.speed_stimm_icon_colour_B
										)
									end
								elseif weapon_name == "content/items/pocketable/syringe_ability_boost_pocketable" then
									if mod.RecolorStimms then
										local argb =
											mod.RecolorStimms.get_stimm_argb_255("syringe_ability_boost_pocketable")
										mod.set_colour_argb(
											stimm_widget.style.texture.color,
											argb[1],
											argb[2],
											argb[3],
											argb[4]
										)
									else
										mod.set_colour_argb(
											stimm_widget.style.texture.color,
											255,
											fs.boost_stimm_icon_colour_R,
											fs.boost_stimm_icon_colour_G,
											fs.boost_stimm_icon_colour_B
										)
									end
								elseif weapon_name == "content/items/pocketable/syringe_corruption_pocketable" then
									if mod.RecolorStimms then
										local argb =
											mod.RecolorStimms.get_stimm_argb_255("syringe_corruption_pocketable")
										mod.set_colour_argb(
											stimm_widget.style.texture.color,
											argb[1],
											argb[2],
											argb[3],
											argb[4]
										)
									else
										mod.set_colour_argb(
											stimm_widget.style.texture.color,
											255,
											fs.corruption_stimm_icon_colour_R,
											fs.corruption_stimm_icon_colour_G,
											fs.corruption_stimm_icon_colour_B
										)
									end
								elseif weapon_name == "content/items/pocketable/syringe_broker_pocketable" then
									if fs.broker_stimm_enable == true then
										if mod.RecolorStimms then
											local argb =
												mod.RecolorStimms.get_stimm_argb_255("syringe_broker_pocketable")
											mod.set_colour_argb(
												stimm_widget.style.texture.color,
												argb[1],
												argb[2],
												argb[3],
												argb[4]
											)
										else
											mod.set_colour_argb(
												stimm_widget.style.texture.color,
												255,
												fs.broker_stimm_icon_colour_R,
												fs.broker_stimm_icon_colour_G,
												fs.broker_stimm_icon_colour_B
											)
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
)
